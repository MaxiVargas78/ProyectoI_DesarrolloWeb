Crear una tienda dinámica que incluya al menos lo siguiente:
• Categorías de productos [SI]
• Productos con título, descripción, imagen y precio.[SI]
• Una página de información sobre la tienda.[SI]
• Hoja de estilo (style.css) aplicada a todos los elementos de su página, correctamente incluida en el <head> [SI]
• Los datos deben provenir de la base de datos (MongoDB).[SI]

-Existen tres categorias de productos
-Cada producto viene con los elementos pedidos
-Pagina de informacion se encuentra al apretar en barra desplegable NavBar y pinchar en Quienes Somos.
-Style.css implementada en heades en conjunto con CSS de Bootstrap
-Todos los datos de los productos vienen de la MongoDB.
